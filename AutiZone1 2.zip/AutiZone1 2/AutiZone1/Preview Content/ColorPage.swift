//////
//////  ColorPage.swift
//////  AutiZone1
//////
//////  Created by Raghad on 30/11/2023.
//////
////
////import SwiftUI
////
////struct ColorPage: View {
////    
////    
////    @State private var shadow1Offset: CGPoint = .init(x: UIScreen.main.bounds.midX + 400,
////                                                          y: UIScreen.main.bounds.minY + 200)
////        @State var isOnPlace: Bool = false
////
////        
////        @State private var shadow2Offset: CGPoint = .init(x: UIScreen.main.bounds.midX + 300,
////                                                          y: UIScreen.main.bounds.minY + 100)
////        @State var isOnPlace2: Bool = false
////        
////        @State private var shadow3Offset: CGPoint = .init(x: UIScreen.main.bounds.midX + 500,
////                                                          y: UIScreen.main.bounds.minY + 250)
////        @State var isOnPlace3: Bool = false
////        
////        
//////        @State private var shadow1Offset = CGSize.zero
//////        @State private var shadow2Offset = CGSize.zero
//////        @State private var shadow3Offset = CGSize.zero
////    
////    @State  var selectedAnimal = "play"
////    @State var sounds: [String] = ["meaw","Dog","bird"]
////    @State var currentSound: String = "Play"
////    let successSound = "good"
////    let failureSound = "ops"
////    
////    var body: some View {
////        GeometryReader { geometry in
////                  VStack {
////                      
////                      HStack{
////                          
////                          Image(systemName: "arrow.backward.circle.fill")
////                              .font(.system(size: 50))
////                              .foregroundColor(Color.white)
////                              .frame(width: 66,height: 200)
////                              
////                          
////                              Text("Drag the item to the correct basket")       .font(.custom("Helvetica Neue", size: 55))
////                                  .fontWeight(.bold)
////                              
////                                  .foregroundColor(.white)
////                                  .padding(.leading,70)
////                      }
////               
////                      
////                   
////                      Spacer()
////                          
////       
////                    
////                          
////                          // Animals' Image
////                          HStack {
////                              Spacer().frame(width: 60)
////                              Image("banana")
////                                  .resizable()
////                                  .scaledToFit()
////                                  .frame(width: 173, height: 175)
////                              Spacer()
////                              
////                              Image("balloon")
////                                  .resizable()
////                                  .scaledToFit()
////                                  .frame(width: 173, height: 175)
////                              Spacer()
////                                
////                              
////                              Image("cap")
////                                  .resizable()
////                                  .scaledToFit()
////                                  .frame(width: 178.89, height: 175)
////                              Spacer().frame(width: 60)
////                              
////      //
////                             
////                          }
////                      Spacer()
////                      //.padding(.bottom)
////                          
////                          // Animals' Shadows
////                          HStack {
////                              Spacer().frame(width: 60)
////                              Image("basket red")
////                                  .resizable()
////                                  .scaledToFit()
////                                  .frame(width: 226, height: 226)
////                              Spacer()
////                              
////                              Image("basket yellow")
////                                  .resizable()
////                                  .scaledToFit()
////                                  .frame(width: 226, height: 226)
////                              Spacer()
////                              
////                              Image("basket blue")
////                                  .resizable()
////                                  .scaledToFit()
////                                  .frame(width: 226, height: 226)
////                              Spacer().frame(width: 60)
////                          }
////                         // .padding(.b,60)
////                      HStack{
////                          // Grass on the left side
////                       
////                          TreeView()
////                          
////                              
////                          Spacer()
////                              
////                          TreeView()
////                          
////                      }
////                   //   .padding(.bottom,)
////                      }
////                  
////                  
////                  }.background{
////                      Color("green").ignoresSafeArea()
////                  }
////                  .onAppear{
////                      SoundManager.instance.playSound(soundName: "Drag")
////                  }
////
////              }
////          }
////
//////      struct ContentView_Previews: PreviewProvider {
//////          static var previews: some View {
//////              ContentView()
//////          }
//////      }
////      struct TreeView: View{
////          var body: some View {
////              Image("grass")
////                  .resizable()
////                  .frame(width: 500,height: 205)
////              
////    }
////}
////
////#Preview {
////    ColorPage()
////}
////
////
////
//
//
import SwiftUI

struct ColorPage: View {
    @State private var balloonOffset: CGSize = .zero
    @State private var capOffset: CGSize = .zero
    @State private var bananaOffset: CGSize = .zero

    @State private var isBalloonInBasket: Bool = false
    @State private var isCapInBasket: Bool = false
    @State private var isBananaInBasket: Bool = false

    @State var banana1: String = "banana"
    @State var balloon1: String = "balloon"
    @State var cap1: String = "cap"
    let successSound = "good"
    let failureSound = "ops"

    var body: some View {
        GeometryReader { geometry in
            VStack {
                HStack {

                    Text("Drag the item to the correct basket color")
                        .font(.custom("Helvetica Neue", size: 55))
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .padding(.top, 70)
                    
                }

                Spacer()

                HStack {
                    Spacer().frame(width: 60)
                    
                    Image(banana1)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 173, height: 175)
                        .offset(bananaOffset)
                        .opacity(isBananaInBasket ? 0 : 1)
                        .gesture(DragGesture()
                            .onChanged { value in
                                bananaOffset = value.translation
                                print(value.translation,"🔴")
                            }
//                            .onEnded { value in
//                               
//                                    handleDrop(itemOffset: value.location, itemSize: CGSize(width: 175, height: 175), correctBasket: "yellow", isInBasket: $isBananaInBasket, itemOffsetBinding: $bananaOffset)
//                                
//                               banana1 = ""
//                                SoundManager.instance.playSound(soundName: successSound)
//                            }
                            .onEnded { value in
                                let xDiff = abs(abs(value.location.x) -  abs(548.0 ))
                                let yDiff = abs(abs(value.location.y) - abs(379.0))
                                if xDiff < 100 && yDiff < 100 {
                                    SoundManager.instance.playSound(soundName: successSound)
                                    banana1 = ""
                                }
                                else{
                                    bananaOffset = .zero
                                    SoundManager.instance.playSound(soundName: failureSound)
                                }
                                
                            }
                        )
                    

               

                    Spacer()

                    Image(balloon1)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 173, height: 175)
                        .offset(balloonOffset)
                        .opacity(isBalloonInBasket ? 0 : 1)
                        .gesture(DragGesture()
//                            .onChanged { value in
//                                balloonOffset = value.translation
//                            }
                            .onChanged { value in
                                balloonOffset = value.translation
                                print(value.translation,"🔴")
                            }
//                            .onEnded { value in
//                                handleDrop(itemOffset: value.location, itemSize: CGSize(width: 173, height: 175), correctBasket: "red", isInBasket: $isBalloonInBasket, itemOffsetBinding: $balloonOffset)
//                                balloon1 = ""
//                                SoundManager.instance.playSound(soundName: successSound)
//
//                            }
                                 
                            .onEnded { value in
                                let xDiff = abs(abs(value.location.x) -  abs(-527.0 ))
                                let yDifff = abs(abs(value.location.y) - abs(387.5))
                                if xDiff < 100 && yDifff < 100 {
                                    SoundManager.instance.playSound(soundName: successSound)
                                    balloon1 = ""
                                }
                                else{
                                    balloonOffset = .zero
                                    SoundManager.instance.playSound(soundName: failureSound)
                                }
                                
                            }
                        )
                    Spacer()

                    Image(cap1)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 178.89, height: 175)
                        .offset(capOffset)
                        .opacity(isCapInBasket ? 0 : 1)
                        .gesture(DragGesture()
//                            .onChanged { value in
//                                capOffset = value.translation
//                            }
                            .onChanged { value in
                                capOffset = value.translation
                                print(value.translation,"🔴")
                            }
                                 
//                            .onEnded { value in
//                                handleDrop(itemOffset: value.location, itemSize: CGSize(width: 178.89, height: 175), correctBasket: "blue", isInBasket: $isCapInBasket, itemOffsetBinding: $capOffset)
//                                cap1 = ""
//                                SoundManager.instance.playSound(soundName: successSound)
//
//
//                            }
                                 
                            .onEnded { value in
                                let xDiff = abs(abs(value.location.x) -  abs(-30.0 ))
                                let yDifff = abs(abs(value.location.y) - abs(350))
                                if xDiff < 100 && yDifff < 100 {
                                    SoundManager.instance.playSound(soundName: successSound)
                                    cap1 = ""
                                }
                                else{
                                    capOffset = .zero
                                    SoundManager.instance.playSound(soundName: failureSound)
                                }
                                
                            }
                                 
                                 
                        )
                    Spacer().frame(width: 60)
                }

                Spacer()

                HStack {
                    Spacer().frame(width: 60)
                    Image("basket red")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 226, height: 226)
                    Spacer()
                    
                    //position track
                    

                    Image("basket yellow")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 226, height: 226)
                    Spacer()

                    Image("basket blue")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 226, height: 226)
                    Spacer().frame(width: 60)
                }

                HStack {
                    TreeView()
                    Spacer()
                    TreeView()
                }
            }
            .background(Color("green1").ignoresSafeArea())
            .onAppear {
                 SoundManager.instance.playSound(soundName: "Drag")
            }
        }
    }

    private func handleDrop(itemOffset: CGPoint, itemSize: CGSize, correctBasket: String, isInBasket: Binding<Bool>, itemOffsetBinding: Binding<CGSize>) {
        let xDiff = abs(itemOffset.x - UIScreen.main.bounds.midX)
        let yDiff = abs(itemOffset.y - UIScreen.main.bounds.minY)

        if xDiff < 100 && yDiff < 100 {
            print("Dropped in the correct basket!")
            withAnimation {
                isInBasket.wrappedValue = true
            }
        } else {
            withAnimation {
                itemOffsetBinding.wrappedValue = .zero
            }
        }
    }
}

struct TreeView: View {
    var body: some View {
        Image("grass")
            .resizable()
            .frame(width: 500, height: 205)
    }
}

struct ColorPage_Previews: PreviewProvider {
    static var previews: some View {
        ColorPage()
    }
}


