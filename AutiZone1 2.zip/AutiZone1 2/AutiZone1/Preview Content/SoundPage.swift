//
//  SoundPage.swift
//  AutiZone1
//
//  Created by Raghad on 03/12/2023.
//

//import SwiftUI
//
//struct SoundPage: View {
//    var body: some View {
//        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
//    }
//}
//
//#Preview {
//    SoundPage()
//}


import SwiftUI
import AVKit

//class SoundManager{
//    static let instance = SoundManager()
//    var player : AVPlayer?
//    func playSound (soundName:String){
//        guard let url = Bundle.main.url(forResource: soundName, withExtension: ".m4a") else {return}
//        do {
//            player = try AVPlayer(url: url)
//            player?.play()
//        }
//        catch let error {
//            
//            print ("Error. \(error.localizedDescription)")
//        }
//        
//    }
//    
//    
//}

struct SoundPage: View {
    @State  var selectedAnimal = "play"
    @State var sounds: [String] = ["meaw","Dog","bird"]
    @State var currentSound: String = "Play"
    let successSound = "good"
    let failureSound = "ops"
    var body: some View {

            VStack{
                HStack{
//                    Image(systemName: "arrow.backward.circle.fill")
//                        .font(.system(size: 50))
//                        .foregroundColor(Color.white)
//                        .frame(width: 66,height: 200)
//                        
                    
//                        .padding(.bottom,800)
//                        .padding(.trailing,1200)
                    
                    
                   // VStack{
                    
                        Text("Match the sound to the correct animal")       .font(.custom("Helvetica Neue", size: 55))
                            .fontWeight(.bold)
                        
                            .foregroundColor(.white)
                            .padding(.leading,40)
                           // .position(x: 700, y: 110)
                   // }
                    
                }.padding(.bottom,90)
              //  Spacer()
                HStack{
                    
                   // HStack{
                        
                        Image("cat").resizable()
                            .frame(width: 226, height: 226)
                            .padding(.leading,70)
                            .onTapGesture {
                                if currentSound == "meaw"{
                                    
                                    SoundManager.instance.playSound(soundName: successSound)
                                    DispatchQueue.main.asyncAfter(deadline: .now()+2){
                                                                            currentSound = "Play"
                                                                            
                                                                        }
                                    
                                }
                                else{
                                    
                                    SoundManager.instance.playSound(soundName: failureSound)
                                    DispatchQueue.main.asyncAfter(deadline: .now()+2){
                                                                            currentSound = "Play"
                                                                            
                                                                        }
                                }
                            }
                        
                   // }
                    Spacer()
                    // .padding(.trailing,170)
                    
                    
                 //   HStack{
                        
                        Image("bird")
                            .resizable()
                            .frame(width: 226, height: 226)
                            .padding(.trailing,10)
                            .onTapGesture {
                                   selectedAnimal = "bird"
                          if currentSound == "bird"{
                                
                          SoundManager.instance.playSound(soundName: successSound)
                              DispatchQueue.main.asyncAfter(deadline: .now()+2){
                                                                      currentSound = "Play"
                                                                      
                                                                  }
                                
                                                            }
                                                            else{
                                
                                                                SoundManager.instance.playSound(soundName: failureSound)
                                                                DispatchQueue.main.asyncAfter(deadline: .now()+2){
                                                                                                        currentSound = "Play"
                                                                                                        
                                                                                                    }
                                                            }
                            }
                    
                    Spacer()
                  //  HStack{
                        
                        Image("dog").resizable()
                            .frame(width: 226, height: 226)
                            .padding(.trailing,70)
                            .onTapGesture {
                                // selectedAnimal = "dog"
                                if currentSound == "Dog"{
                                    
                                    SoundManager.instance.playSound(soundName: successSound)
                                    DispatchQueue.main.asyncAfter(deadline: .now()+2){
                                                                            currentSound = "Play"
                                                                            
                                                                        }
                                    
                                }
                                else{
                                    
                                    SoundManager.instance.playSound(soundName: failureSound)
                                    DispatchQueue.main.asyncAfter(deadline: .now()+2){
                                                                            currentSound = "Play"
                                                                            
                                                                        }
                                }
                            }
                        
                    }
               // }
                Spacer()
//
               // VStack{
                    
                    
                    Button(action: {
                        // Action to perform when the button is tapped
                        sounds.shuffle()
                        
                            currentSound = sounds.first!
                            SoundManager.instance.playSound(soundName: currentSound)
                        
                        
                        
                        
                    })
                {
                        // if statment
                        HStack{
                            // HStack{
                            Image(systemName: "speaker.wave.3.fill").foregroundColor(Color.white)
                                .font(.system(size: 30))
                            
                            
                            Text("\(currentSound)")
                                .font(.custom("Helvetica Neue", size: 30))
                                .fontWeight(.bold)
                            ///.font(.headline)
                                .foregroundColor(.white)
                            
                             
                            
                            
                            //   }
                            
                        }
                        .frame(width: 370,height:80)
                        .background(Color("o"))
                        .mask(RoundedRectangle(cornerRadius: 30, style: .continuous))
                        
                        
                }.padding(.bottom,1)
                
                
                
                
                HStack{

                    TreeView()
                    
                        
                        
                    Spacer()
                        
                    TreeView()

                }//.padding(.top,30)
                
            
            
            
            
            
        }
            .background{
                Color("y").ignoresSafeArea()
            }

            .onAppear{
                SoundManager.instance.playSound(soundName: "Mach")


        }
        
    }
    
    struct ContentView_Previews: PreviewProvider {
        static var previews: some View {
            SoundPage()
        }
    }
}



//struct TreeView: View{
//    var body: some View {
//        Image("tree")
//            .resizable()
//            .frame(width: 500,height: 205)
//        
//    }
//}


#Preview {
    SoundPage()
}

