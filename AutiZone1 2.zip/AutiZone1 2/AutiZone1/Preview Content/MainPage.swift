//
//  MainPage.swift
//  AutiZone1
//
//  Created by Raghad on 28/11/2023.
//

import SwiftUI

struct MainPage: View {
    var body: some View {
        NavigationStack{
                   ZStack {
                       Image( "Background")
                           .resizable()
                           .aspectRatio(contentMode: .fill)
                           .edgesIgnoringSafeArea(.all)
                       
                       
                      
                       
                       VStack{
                           Spacer()
                       
                       
                           HStack{
                               NavigationLink {
//                                   Text("Test")
                                   SoundPage()
                               } label: {
                                   ZStack{
                                       
                                       RoundedRectangle(cornerRadius:30).foregroundColor(Color("o") )
                                           .frame(width: 350, height: 300)
                                       
                                       
                                       Text("SOUNDS")
                                           .font(.custom("Helvetica Neue", size: 55))
                                           .fontWeight(.bold)
                                           .foregroundColor(.white)
                                       
                                   }
                                   .overlay(alignment: .topTrailing) {
                                       Image("Rectangle 5")
                                           .resizable()
                                           .scaledToFit()
                                           .frame(width: 130 ,height:150)
                                           .offset(y:-60)
                                       
                                   }
                                   
                               }
                               
                               Spacer()
                               NavigationLink {
//                                   Text("Test")
                                   ShadowPage()
                               } label: {
                                   ZStack{
                                       
                                       RoundedRectangle(cornerRadius:30).foregroundColor(Color("green1") )
                                           .frame(width: 350, height: 300)
                                       
                                       
                                       Text("SHAPES")
                                           .font(.custom("Helvetica Neue", size: 55))
                                           .fontWeight(.bold)
                                           .foregroundColor(.white)
                                       
                                   }
                                   .overlay(alignment: .topTrailing) {
                                       Image("Rectangle 11")
                                           .resizable()
                                           .scaledToFit()
                                           .frame(width: 130 ,height:150)
                                           .offset(y:-60)
                                       
                                   }
                               }
                               Spacer()
                               NavigationLink {
//                                   Text("Test")
                                   ColorPage()
                               } label: {
                                   ZStack{
                                       
                                       RoundedRectangle(cornerRadius:30).foregroundColor(Color("yo") )
                                           .frame(width: 350, height: 300)
                                       
                                       
                                       Text("COLORS")
                                           .font(.custom("Helvetica Neue", size: 55))
                                           .fontWeight(.bold)
                                           .foregroundColor(.white)
                                       
                                   }
                                   .overlay(alignment: .topTrailing) {
                                       Image("splash-2 5")
                                           .resizable()
                                           .scaledToFit()
                                           .frame(width: 130 ,height:150)
                                           .offset(y:-60)
                                       
                                   }
                               }
                           }
                           .padding(.top,100)
                           Spacer()
                        
                       }
                       .padding(.horizontal, 200)
                   }
                            

                }
    }
}

#Preview {
    MainPage()
}
