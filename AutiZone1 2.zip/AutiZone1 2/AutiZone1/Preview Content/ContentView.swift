//
//  ContentView.swift
//  AutiZone1
//
//  Created by Raghad on 22/11/2023.
//

//

//import SwiftUI
//
//struct ContentView: View {
//    @State private var logoScale: CGFloat = 0.5
//    @State private var isLogoVisible = false
//
//    var body: some View {
//        ZStack {
//            Image("photo1")
//                .resizable()
//                .scaledToFill()
//                .edgesIgnoringSafeArea(.all)
//
//            Image("photo2")
//                .resizable()
//                .aspectRatio(contentMode: .fit)
//                .scaleEffect(logoScale)
//                .onAppear {
//                    withAnimation(.easeInOut(duration: 2.5)) {
//                        isLogoVisible = true
//                        logoScale = 1.0
//                    }
//                }
//                .opacity(isLogoVisible ? 1 : 0)
//        }
//    }
//}
//
//struct ContentView_Previews: PreviewProvider {
//    static var previews: some View {
//        ContentView()
//    }
//}


//import SwiftUI
//
//struct ContentView: View {
//    @State private var logoScale: CGFloat = 0.3
//    @State private var logoOffset: CGSize = .zero
//    @State private var isLogoVisible = false
//
//    var body: some View {
//        ZStack {
//            Image("BG")
//                .resizable()
//                .scaledToFill()
//                .edgesIgnoringSafeArea(.all)
//            
//           
//            Image("logo")
//                .resizable()
//                .aspectRatio(contentMode: .fit  )
//                .scaleEffect(logoScale)
//                .offset(logoOffset)
//            
//                .scaledToFit()
//                .frame(width: 900)
//                .padding(.leading, -70)
//            
//                .onAppear {
//                    withAnimation(.easeInOut(duration: 1.5)) {
//                        isLogoVisible = true
//                        logoScale = 1.0
////                        logoOffset = .zero
//                        logoOffset = CGSize(width: 0, height: -90)
//
//                    }
//                }
//                .opacity(isLogoVisible ? 1 : 0)
//        
//            
//        }
//    }
//    
//        
//}
//
//struct ContentView_Previews: PreviewProvider {
//    static var previews: some View {
//        ContentView()
//    }
//}


import SwiftUI

struct ContentView: View {
    @State private var logoScale: CGFloat = 0.3
    @State private var logoOffset: CGSize = .zero
    @State private var isLogoVisible = false
    @State private var nextPageIsActive = false

    var body: some View {
        ZStack {
            Image("BG")
                .resizable()
                .scaledToFill()
                .edgesIgnoringSafeArea(.all)

            Image("logo")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .scaleEffect(logoScale)
                .offset(logoOffset)
                .scaledToFit()
                .frame(width: 900)
                .padding(.leading, -70)
                .onAppear {
                    withAnimation(.easeInOut(duration: 1.5)) {
                        isLogoVisible = true
                        logoScale = 1.0
                        logoOffset = CGSize(width: 0, height: -90)
                    }

                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
                        nextPageIsActive = true
                    }
                }
                .opacity(isLogoVisible ? 1 : 0)
        }
        .fullScreenCover(isPresented: $nextPageIsActive, content: {
            NextPage()
        })
    }
}

struct NextPage: View {
    var body: some View {
        // the content for the next page goes here
//        Text("Welcome to the Next Page!")
//       ShadowDrag()
        MainPage()
//        ShadowPage()
//        Test()
   //     ColorPage()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}




