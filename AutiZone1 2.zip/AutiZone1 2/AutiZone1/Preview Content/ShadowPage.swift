//
//  ShadowPage.swift
//  AutiZone1
//
//  Created by Raghad on 30/11/2023.
//

import SwiftUI
import AVKit

class SoundManager{
    static let instance = SoundManager()
    var player : AVPlayer?
    func playSound (soundName:String){
        guard let url = Bundle.main.url(forResource: soundName, withExtension: ".m4a") else {return}
        do {
            player = try AVPlayer(url: url)
            player?.play()
        }
        catch let error {
            
            print ("Error. \(error.localizedDescription)")
        }
    }
}


struct ShadowPage: View {
    
    let successSound = "good"
    let failureSound = "ops"
    
    @State private var animal1Offset: CGPoint = .init(x: UIScreen.main.bounds.midX + 450,
                                                      y: UIScreen.main.bounds.minY + 250)
    @State var isOnPlace: Bool = false

    
    @State private var animal2Offset: CGPoint = .init(x: UIScreen.main.bounds.midX + 250,
                                                      y: UIScreen.main.bounds.minY + 130)
    @State var isOnPlace2: Bool = false
    
    
    @State private var animal3Offset: CGPoint = .init(x: UIScreen.main.bounds.midX + 450,
                                                      y: UIScreen.main.bounds.minY + 80)
    @State var isOnPlace3: Bool = false
    
    @State private var shadow1Offset = CGSize.zero
    @State private var shadow2Offset = CGSize.zero
    @State private var shadow3Offset = CGSize.zero
         
         //CGSize type is used to store width and height values, .zero initializes the offsets with zero values.
         
         // @State is used to declare properties whose values can be modified and trigger a view update when the value changes.
         
         var body: some View {
             GeometryReader { geometry in
                 background(geometry)
                 // Shadows
                 shadows(geometry)
                 // Animals
                 animals(geometry)
             }
         }
    
    private func background(_ geometry: GeometryProxy) -> some View {
        ZStack {
            HStack{
                // Grass on the left side
                Image("grass")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 500, height: 205)
                    .background(
                        Color.clear
                    )
                    .padding(.top, 660)
                
                // Grass on the right side
                Image("grass")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 500, height: 205)
                    .background(
                        Color.clear
                    )
                    .padding(.top, 660)
                    .padding(.leading, 360)
            }//.padding(.leading, 360)
            
            VStack{
                // Title
                Text("Match the animals to its shadow")
                    .font(.custom("Helvetica Neue", size: 55))
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                    .background(
                        Color.clear
                    )
                    .padding(.bottom, 1000)
            }
        }
        .background{
            Color("g").ignoresSafeArea()
        }
        .onAppear{
            SoundManager.instance.playSound(soundName: "Shadow")
        }
    }
         
    private func animals(_ geometry: GeometryProxy) -> some View {
        VStack {
            Image("animal1")
                .resizable()
                .scaledToFit()
                .frame(width: 250, height: 250)
                .background(
                    Color(isOnPlace ? .green : .clear)
                        .frame(width: 200, height: 200)
                        .clipShape(Circle())
                )
                .position(animal1Offset)
                .gesture(DragGesture()
                    .onChanged { value in
                        let targetedPoint: CGPoint = .init(x: 300, y: 300)
                        withAnimation {
                            animal1Offset = value.location
                            if value.location.x <= targetedPoint.x && value.location.y <= targetedPoint.x {
                                isOnPlace = true
                            } else {
                                isOnPlace = false
                            }
                        }
                        
                    }
                    .onEnded { value in
                        let targetedPoint: CGPoint = .init(x: 300, y: 300)
                        
                        let xDiff = abs(abs(value.location.x) -  abs(250.5))
                        let yDiff = abs(abs(value.location.y) - abs(305.0))
                        
                        withAnimation {
                            if value.location.x <= targetedPoint.x && value.location.y <= targetedPoint.x {
                                animal1Offset = .init(x: 200, y: 250)
                                withAnimation(.spring().delay(0.4)) {
                                    isOnPlace = false
                                }
                            } else {
                                animal1Offset = .init(x: UIScreen.main.bounds.midX + 450,
                                                     y: UIScreen.main.bounds.minY + 250)
                                isOnPlace = false
                            }
                        }
                        if xDiff < 100 && yDiff < 100 {
                            SoundManager.instance.playSound(soundName: successSound)
                        }
                        else{
                            SoundManager.instance.playSound(soundName: failureSound)
                        }
                    }
                )
            
            Image("animal2")
                .resizable()
                .scaledToFit()
                .frame(width: 250, height: 250)
                .background(
                    Color(isOnPlace2 ? .green : .clear)
                        .frame(width: 200, height: 200)
                        .clipShape(Circle())
                )
                .position(animal2Offset)
                .gesture(DragGesture()
                    .onChanged { value in
                        let targetedPoint: CGPoint = .init(x: 300, y: 300)
                        withAnimation {
                            animal2Offset = value.location
                            if value.location.x <= targetedPoint.x && value.location.y <= targetedPoint.x {
                                isOnPlace2 = true
                            } else {
                                isOnPlace2 = false
                            }
                        }
                        
                    }
                         
                    .onEnded { value in
                        let targetedPoint: CGPoint = .init(x: 300, y: 300)
                        
                        let xDiff = abs(abs(value.location.x) -  abs(286.5))
                        let yDiff = abs(abs(value.location.y) - abs(114.0))
                        
//                        if xDiff < 100 && yDiff < 100 {
//                            print(value.location,"🔥")
////                            print("Good🔥")
//                        }
//                        print(value.location,"🔴")
                            
                        withAnimation {
                            if value.location.x <= targetedPoint.x && value.location.y <= targetedPoint.x {
                                animal2Offset = .init(x: 275, y: 110)
                                withAnimation(.spring().delay(0.4)) {
                                    isOnPlace2 = false
                                }
                            } else {
                                animal2Offset = .init(x: UIScreen.main.bounds.midX + 250,
                                                     y: UIScreen.main.bounds.minY + 130)
                                isOnPlace2 = false
                            }
                        }
                        if xDiff < 100 && yDiff < 100 {
                            SoundManager.instance.playSound(soundName: successSound)
                        }
                        else{
                         SoundManager.instance.playSound(soundName: failureSound)
                         }
                    }
                )
                .padding()
            
            
            Image("animal3")
                .resizable()
                .scaledToFit()
                .frame(width: 250, height: 250)
                .background(
                    Color(isOnPlace3 ? .green : .clear)
                        .frame(width: 200, height: 200)
                        .clipShape(Circle())
                )
                .position(animal3Offset)
                .gesture(DragGesture()
                    .onChanged { value in
                        let targetedPoint: CGPoint = .init(x: 300, y: 300)
                        withAnimation {
                            animal3Offset = value.location
                            if value.location.x <= targetedPoint.x && value.location.y <= targetedPoint.x {
                                isOnPlace3 = true
                            } else {
                                isOnPlace3 = false
                            }
                        }
                        
                    }
                    .onEnded { value in
                        let targetedPoint: CGPoint = .init(x: 300, y: 300)
                        
                        let xDiff = abs(abs(value.location.x) -  abs(207.0))
                        let yDiff = abs(abs(value.location.y) - abs(73.5))
                        

                        
                        withAnimation {
                            if value.location.x <= targetedPoint.x && value.location.y <= targetedPoint.x {
                                animal3Offset = .init(x: 200, y: 80)
                                withAnimation(.spring().delay(0.4)) {
                                    isOnPlace3 = false
                                }
                            } else {
                                animal3Offset = .init(x: UIScreen.main.bounds.midX + 450,
                                                     y: UIScreen.main.bounds.minY + 80)
                                isOnPlace3 = false
                            }
                        }
                        if xDiff < 100 && yDiff < 100 {
                            SoundManager.instance.playSound(soundName: successSound)
                        }
                        else{
                            SoundManager.instance.playSound(soundName: failureSound)
                        }
                    }
                )
                .padding()
        }
    }

    private func shadows(_ geometry: GeometryProxy) -> some View {
        VStack {
            Image("shadow1")
                .resizable()
                .scaledToFit()
                .frame(width: 240, height: 240)
                .position(x: 200, y: 250)
            
            Image("shadow2")
                .resizable()
                .scaledToFit()
                .frame(width: 240, height: 240)
                .position(x: 300, y: 130)
            
            Image("shadow3")
                .resizable()
                .scaledToFit()
                .frame(width: 240, height: 240)
                .position(x: 218, y: 88)
        }
    }
}
//class SoundManager{
//    static let instance = SoundManager()
//    var player : AVPlayer?
//    func playSound (soundName:String){
//        guard let url = Bundle.main.url(forResource: soundName, withExtension: ".m4a") else {return}
//        do {
//            player = try AVPlayer(url: url)
//            player?.play()
//        }
//        catch let error {
//            
//            print ("Error. \(error.localizedDescription)")
//        }
//        
//    }
//    
//    
//}
//
//
//struct ShadowPage: View {
//
////    @State  var selectedAnimal = "play"
////    @State var sounds: [String] = ["meaw","Dog","bird"]
////    @State var currentSound: String = "Play"
//    let successSound = "good"
//    let failureSound = "ops"
//    
//        @State private var animal1Offset = CGSize.zero
//         @State private var animal2Offset = CGSize.zero
//         @State private var animal3Offset = CGSize.zero
//         
//         @State private var shadow1Offset = CGSize.zero
//         @State private var shadow2Offset = CGSize.zero
//         @State private var shadow3Offset = CGSize.zero
//         
//         //CGSize type is used to store width and height values, .zero initializes the offsets with zero values.
//         
//         // @State is used to declare properties whose values can be modified and trigger a view update when the value changes.
//         
//         var body: some View {
//             GeometryReader { geometry in
//                 background(geometry)
//                 // Shadows
//                 shadows(geometry)
//                 // Animals
//                 animals(geometry)
//             }
//         }
//         
//         private func background(_ geometry: GeometryProxy) -> some View {
//            VStack {
//   
//                
//                 
//                 Text("Match the animals to its shadow")
//                     .font(.custom("Helvetica Neue", size: 55))
//                     .fontWeight(.bold)
//                     .foregroundColor(.white)
//                     .position(x: 680, y: 60)
//                 
//                HStack{
//                    
//                    
//                }
////
////                 Image(systemName: "arrow.backward.circle.fill")
////                     .font(.system(size: 50))
////                     .foregroundColor(Color.white)
////                     .frame(width: 66,height: 200)
//            }.background{
//                Color("g").ignoresSafeArea()
//            }
//             .onAppear{
//                 SoundManager.instance.playSound(soundName: "Shadow")
//             }
//         }
//         
//         private func animals(_ geometry: GeometryProxy) -> some View {
//             VStack {
//                 Image("animal1")
//                     .resizable()
//                     .scaledToFit()
//                     .frame(width: geometry.size.width / 4, height: geometry.size.height / 4)
//                     .position(x: geometry.size.width * 0.83, y: geometry.size.height * 0.25)
//                     .offset(animal1Offset)
//                     .gesture(DragGesture()
//                         .onChanged { value in
//                             animal1Offset = value.translation
//                         }
//                         .onEnded { value in
//                             let xDiff = abs(abs(value.location.x) -  abs(223.5))
//                             let yDiff = abs(abs(value.location.y) - abs(285.0))
//                             if xDiff < 100 && yDiff < 100 {
//                                 SoundManager.instance.playSound(soundName: successSound)
//                                 
//                             }
//                             else{
//                                 animal1Offset = .zero
//                                 SoundManager.instance.playSound(soundName: failureSound)
//                             }
//                            
//
//                             
//                         }
//                     )
//                 
//                 Image("animal2")
//                     .resizable()
//                     .scaledToFit()
//                     .frame(width: geometry.size.width / 4, height: geometry.size.height / 4)
//                     .position(x: geometry.size.width * 0.69, y: geometry.size.height * 0.16)
//                     .offset(animal2Offset)
//                     .gesture(DragGesture()
//                         .onChanged { value in
//                             animal2Offset = value.translation
//                             print(value.translation,"🔴")
//                         }
//                         .onEnded { value in
//                             let xDiff = abs(abs(value.location.x) -  abs(347.5))
//                             let yDiff = abs(abs(value.location.y) - abs(176.0))
//                             if xDiff < 100 && yDiff < 100 {
//                                 SoundManager.instance.playSound(soundName: successSound)
//                             }
//                             else{
//                                 animal2Offset = .zero
//                                 SoundManager.instance.playSound(soundName: failureSound)
//                             }
//                             
//                         }
//                     )
//                 
//                 Image("animal3")
//                     .resizable()
//                     .scaledToFit()
//                     .frame(width: geometry.size.width / 4, height: geometry.size.height / 4)
//                     .position(x: geometry.size.width * 0.8, y: geometry.size.height * 0.1)
//                     .offset(animal3Offset)
//                     .gesture(DragGesture()
//                         .onChanged { value in
//                             animal3Offset = value.translation
//                         }
//                         .onEnded { value in
//                             let xDiff = abs(abs(value.location.x) -  abs(200.0))
//                             let yDiff = abs(abs(value.location.y) - abs(58.5))
//                             if xDiff < 100 && yDiff < 100 {
//                                 SoundManager.instance.playSound(soundName: successSound)
//
//                             }
//                             else{
//                                 animal3Offset = .zero
//                                 SoundManager.instance.playSound(soundName: failureSound)
//                             }
//                            
//                         }
//                     )
//             }
//         }
//         
//         private func shadows(_ geometry: GeometryProxy) -> some View {
//             VStack {
//                 Image("shadow1")
//                     .resizable()
//                     .scaledToFit()
//                     .frame(width: geometry.size.width / 4, height: geometry.size.height / 4)
//                     .position(x: geometry.size.width * 0.16, y: geometry.size.height * 0.25)
//                     .offset(shadow1Offset)
//                 
//                 Image("shadow2")
//                     .resizable()
//                     .scaledToFit()
//                     .frame(width: geometry.size.width / 4, height: geometry.size.height / 4)
//                     .position(x: geometry.size.width * 0.25, y: geometry.size.height * 0.14)
//                     .offset(shadow2Offset)
//                 
//                 Image("shadow3")
//                     .resizable()
//                     .scaledToFit()
//                     .frame(width: geometry.size.width / 4, height: geometry.size.height / 4)
//                     .position(x: geometry.size.width * 0.13, y: geometry.size.height * 0.1)
//                     .offset(shadow3Offset)
//             }
//             
//    }
//    
//}

#Preview {
    ShadowPage()
}
