//
//  AutiZone1App.swift
//  AutiZone1
//
//  Created by Raghad on 22/11/2023.
//

import SwiftUI

@main
struct AutiZone1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
       //     SoundPage()
       //   ColorPage()
         //  ShadowPage()
        }
    }
}
